# Christol's conjecture for non-resonant globally bounded ₃F₂(a₁,a₂,a₃;b,1) series — version 1.5

David Jordan (Maynooth University). Revision of v1.4 following an AI-assisted manuscript review,
17 November 2026. The reviews of v1.3 and v1.4 were AI-assisted manuscript reviews, not independent
journal peer review; the paper has not been refereed.

| File | Contents |
|---|---|
| `christol_w1.pdf` | the paper (39 pp.) |
| `christol_w1.tex`, `.bib`, `.bbl` | LaTeX source (amsart, natbib numeric) |
| `CHANGES_AND_RESPONSE_v1_5.md` | change log and response to the review of v1.4 |
| `VERIFICATION_LOG.md` | what was rerun or checked, and what was not |
| `DEPENDENCY_TABLE.md` | imported theorems, proved deductions, unresolved steps, computational status |
| `NOTES_FOR_AUTHOR.md` | private notes (not for submission) |
| `supplementary/` | scripts, stored outputs, search code, tests, audits |
| `verify_all.sh` | the default verification command |
| `SHA256SUMS` | checksums of every other file |

## Verify (one command)

    sh verify_all.sh          # checksums + all checks, about 5 min (Python >= 3.8, NumPy)

Optional, not part of the default (about 8 min): recompute the 50-coefficient comparisons of the
312 stored survivors of the numerical search:

    cd supplementary && python3 -I audit/audit_numerical.py --recompute-survivors

## Build the paper

    latexmk -pdf christol_w1.tex

The v1.4 response document (titled "Response to the referee", written in reply to an AI-assisted
manuscript review) is in the v1.4 archive, which is preserved unchanged.
