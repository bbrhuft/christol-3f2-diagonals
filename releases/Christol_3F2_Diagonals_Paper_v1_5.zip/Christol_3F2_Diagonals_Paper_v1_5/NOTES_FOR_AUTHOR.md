# Notes for the author: paper v1.5

17 November 2026. These notes are for you, not for submission.

## What changed in v1.5

The full account is in CHANGES_AND_RESPONSE_v1_5.md. None of the changes affects the proof of Theorem A.

- **Search coverage corrected (Appendix C).** The B2 and B3 numerical families were smaller than the paper said. The code picked a "representative" for each quadratic factor separately, and that is not a valid symmetry reduction: (1−u)(1−2v) became (1−u)(1−2u), which has a different diagonal. As instructed, the enumeration was not changed or rerun. Instead the paper now describes exactly what was searched:
  - B2: pairs from a pool of 854 quadratics, covering about 55% of the pair classes first described;
  - B3: triples from a pool of 77, of which 45,070 triples correspond to described ones and 28,080 do not.
  The paper says no representation of H was found **among the candidates enumerated**.
- **Verification.**
  - The engine test now fails properly.
  - The survivor check is labelled as reading stored records, and an optional `--recompute-survivors` routine exists; I ran it, and all 312 agree.
  - A failure-injection test shows that `run_checks.sh` really stops on failures.
  - New single command: `sh verify_all.sh`.
- **Mathematical text.**
  - Lemma 2.1(ii): notation fix (no tensor product).
  - Plain-language definition of a diagonal corrected.
  - Eisenstein wording made precise.
  - Target grid stated exactly.
  - §8.1(vi) now refers to Step 7.
- **Provenance.** The AI statement now says that the v1.3 and v1.4 "referee" reports were AI-assisted manuscript reviews, not peer review, and credits them with example (C.1) and with finding the B2/B3 problem.
- **Deligne LNM 163.** I checked Théorèmes II.5.9 and II.7.9 myself against the IAS scan you supplied, together with I.2.17, II.4.5 and II.6.13–6.14. The citations are now exact, and the verification log records them as my own checks.

## Still to do before any submission

1. Have a specialist read the proof, especially Prop. 6.2 and Lemma 6.4. No AI audit replaces that.
2. Check the references still marked "not rechecked" in VERIFICATION_LOG.md, §6d.
3. If you want B2 and B3 to cover the families as first described, a new run would be needed: about 293,000 more pair classes in B2, plus the missing triples in B3. This revision deliberately did not do that.

---

# Notes from v1.4

## What changed in v1.4 (revision after an AI-assisted manuscript review of v1.3)

The full point-by-point account is in RESPONSE_TO_REFEREE.md in the v1.4 archive. That title is misleading: the "referee" was an AI-assisted manuscript review, not journal peer review. In short:

- **New title:** *Christol's conjecture for non-resonant globally bounded ₃F₂(a₁,a₂,a₃;b,1) series*.
- **Numbered citations** (natbib `numbers`).
- **Plain-language summary** shortened to about half; kept after the abstract.
- **Proofs expanded, no new results.**
  - §2.1: new Lemma 2.1 (henselization = algebraic power series, with proof).
  - Lemma 2.3 narrowed to how Harder–Kramer-Miller state it.
  - Theorem 4.3: proof in eight explicit steps.
  - New Lemma 5.3 (de Rham descent).
  - Proposition 6.2 redone over ℚ̄, then descended to a number field.
  - Lemma 6.4 with a Čech–de Rham representative.
  - New Lemma 6.5 (node coordinates).
  - New Proposition 7.3 (the period-to-diagonal mechanism in one statement).
- **Appendix C rewritten.**
  - New Lemma C.1 (a transcendence criterion that justifies every exclusion).
  - Strict use of the terms *excluded*, *unresolved*, *not examined* and *survivor*.
  - The ₂F₁ example from the AI-assisted review is now (C.1).
  - The numerical bound is now (C.3).
  - Every hint of a complexity lower bound for H has been removed.
- **Appendix B:** reproduction commands and versions, plus Table 3 listing every imported result.
- **Supplementary material.**
  - `run_checks.sh`.
  - `audit/` (three scripts).
  - `scripts/eisenstein_counterexample.py`.
  - Pass/fail exit codes on all checks.
  - Search README rewritten.
  - Stale docstring in `family_ab.py` fixed (the code itself is unchanged).

## Decisions you may want to revisit

1. **Plain-language summary placement.** The AI-assisted review suggested shortening it or moving it. I shortened it and kept it after the abstract, as you asked earlier. A journal may ask for it to be moved to the end or removed.
2. **Acknowledgment.** (Superseded in v1.5.) Example (C.1) is now credited in the AI statement to the AI-assisted review.
3. **Sources not rechecked** (listed in VERIFICATION_LOG.md): Deligne LNM 163 II.5.9, Katz 1970, SGA 7 I IX §3, SGA 7 II XIV, Liu §§6.4 and 10.3, and the original Beukers–Heckman and Christol 1987 papers. Before submission, someone with library access should confirm the section citations, or replace them with theorem numbers.
4. **No gap was found in Theorem A**, but this audit is not a substitute for review by a specialist in arithmetic geometry. The steps most worth an expert's eye are Prop. 6.2 (semistable model and descent) and Lemma 6.4 (meromorphic representative).

## Still open from earlier versions

- Priority of Proposition D(a) (the "Trivialement diagonale" email cited by Abdelaziz–Koutschan–Maillard).
- Christol's own source for S₇ as a suggested counterexample (his 2014 Grenoble talk).

---

# Notes from v1.3

## What changed in v1.3

After reading Rivoal–Roques (2014) and the journal version of Harder–Kramer-Miller (2026):

- **The 1/7 series S₇ = 3F2(1/7, 2/7, 4/7; 1/2, 1) is now a headline result.** Harder and Kramer-Miller (Remark 4.2) say Christol suggested it as a potential counterexample to his conjecture and that it was unknown in 2026 whether it is a diagonal. Rivoal and Roques (Proposition 1) prove, assuming the Rohrlich–Lang conjecture, that it is not a Hadamard product of finitely many algebraic series.
- **New Corollary E:** assuming Rohrlich–Lang, S₇ is a diagonal of a rational function in three variables but not a Hadamard product of algebraic series. This removes the assumption of Christol's conjecture from the observation in Harder–Kramer-Miller's Remark 4.2. Placed after Proposition D so that A–D keep their letters.
- **New Remark 8.3 (Grades):** diagonal grade exactly 2 for every series of Theorem A (lower bound also by Harder–Kramer-Miller Theorem 3.7); Hadamard grade exactly 2 for the series of Proposition D(a); for S₇, diagonal grade 2 and Hadamard grade ∞ under Rohrlich–Lang; Christol's open question for H. The Proposition D remark is now Remark 8.4.
- **Remark 8.4(2):** the Abdelaziz–Koutschan–Maillard footnote is now described as not matching anything in Rivoal–Roques, whose result concerns S₇. (I searched the whole paper; the series 3F2(1/9, 4/9, 7/9; 2/3, 1) does not occur in it.)
- **Abstract, plain-language summary and introduction** mention S₇ and the Hadamard-grade consequence; the summary's Limitations paragraph says that this part relies on the Rohrlich–Lang conjecture.
- **Related work:** new paragraph on Hadamard and diagonal grades (Allouche–Mendès France 2011, Rivoal–Roques 2014, Harder–Kramer-Miller 2026). Notation section defines hg and dg.
- **Appendix C** links family (ii) to Christol's question about H and notes that the negative result for S₇ agrees with Rivoal–Roques.
- **Bibliography:** Harder–Kramer-Miller now cited as IMRN 2026(8), rnag040, doi:10.1093/imrn/rnag040 (confirmed; their Lemma 3.2 has the same number in the journal version). Added Allouche–Mendès France (2011).

## Status of earlier must-check items

- Rivoal–Roques footnote conflict: **resolved** (misattribution in the Abdelaziz et al. footnote; see above).
- Harder–Kramer-Miller article number and lemma number: **resolved**.
- Priority of Proposition D(a) (the "Trivialement diagonale" email): still open.

## New must-check items (v1.3)

1. **"Christol suggested S₇ as a potential counterexample."** The paper attributes this to Harder–Kramer-Miller, Remark 4.2. Rivoal–Roques say only that Christol considered S₇ in his 2014 Grenoble talk ("Journées holonomes") in connection with his conjecture. If you can find Christol's slides, cite them directly.
2. **Corollary E is only as good as Theorem A for S₇.** It is now the most striking consequence of the paper, and a referee will look hard at it. Ask the expert reviewer to check the S₇ case specifically (N = 14, field ℚ(√−7), abelian threefolds).

---

# Notes from v1.2

## What changed in v1.2

The computer search for an explicit representation of H found none, but it showed that the two Abdelaziz–Koutschan–Maillard (AKM) series are diagonals for an elementary reason. The paper now says so.

- **Proposition D rewritten.** New part (a): for every rational s and c = 1/3 or 2/3, 3F2(s/3, (s+1)/3, (s+2)/3; 1−c, 1; x) = T_s(x) ⋆ (1−x)^(−c), where T_s is a trisection of (1−y)^(−s). This covers both AKM series and infinitely many more. Part (b) is the old two-variable formula, restated with s = 1 − r; it is now presented only as a two-variable version of AKM's one-parameter family, not as an improvement for their two series.
- **New remark (now Remark 8.4)** explains why AKM missed the factorization (it needs auxiliary parameters that cancel), records the conflict with their Rivoal–Roques footnote, and says plainly that the identity may be known.
- **Introduction and related work.** The Bostan et al. list is now described as "not obviously reducible" (their own wording), with a sentence that some members are elementary Hadamard products and H is not. The related-work paragraph now credits AKM's explicit six-variable rational functions. An inaccurate sentence ("no proof for any F_ab with b ∉ Z other than the two AKM series") was removed: AKM's one-parameter family already gave infinitely many.
- **Plain-language summary:** two sentences added on the neighbouring series and the search.
- **New Appendix C** reports the search: two exact families (Beukers–Heckman), five numerical families (924 million candidates), controls, and the result that among the 16 globally bounded non-resonant 3F2(a; b, 1) with parameters in (1/9)ℤ, explicit representations were found for exactly the four covered by Proposition D(a).
- **New concluding remark (5)** on elementary cases.
- **Data availability** now gives the GitHub address.
- **Supplementary material:** `scripts/hadamard_identities.py` (exact check of Proposition D(a) to n = 200) and the `search/` folder.

## Must check before submission (new in v1.2)

1. **Rivoal and Roques (2014), J. Number Theory 145, 579–603.** AKM's footnote says this paper proves that 3F2(1/9, 4/9, 7/9; 2/3, 1) cannot be written as a Hadamard product. Proposition D(a) shows that it is one (the identity is exact and elementary; see the script). Read Rivoal and Roques to see what they actually prove. Most likely their statement concerns a different series or a narrower notion, or AKM's footnote misquotes it. Adjust Remark 8.4(2) accordingly. (Resolved in v1.3.) I could not open the paper; it is cited only to report AKM's statement.
2. **Priority of Proposition D(a).** AKM thank Bostan for an email titled "Trivialement diagonale" (16 March 2019), which may be exactly this observation. Search the literature (Bostan–Yurkevich 2022, Harder–Kramer-Miller 2026 on Hadamard grade) and, if it is known, cite it and present D(a) as a recollection.

---

# Notes from v1.1 (still relevant)

## Package contents

- `christol_w1.tex`, `christol_w1.bib`, `christol_w1.bbl`: LaTeX source (amsart, natbib; numeric citations since v1.4). Include the `.bbl` file if you submit to arXiv.
- `christol_w1.pdf`: compiled paper (38 pages in v1.4), no LaTeX warnings.
- `supplementary/`: the scripts and their stored outputs. Run `sh run_checks.sh` from that folder (about 4 minutes; `--quick` for 15 s). See VERIFICATION_LOG.md.

## What this revision changed

### One error corrected

- **Genus bound (old Prop. 7.1, now Prop. 6.1).** The old text said the curves have "genus at least 9" and "rank 2g ≥ 18". That is true only for N = 9. In general the abelian scheme has dimension (3/2)φ(N) ≥ 3, so the bound is genus ≥ 3. Nothing downstream used the wrong number.

### Statements made more precise

- **Proposition 3.1 (two Hodge levels).** Fedorov's formula can be read on the connection or on its local system of solutions, and these are dual to each other, which reverses the order of the Hodge numbers. The old text did not say which was meant. The proposition is now worded so that it holds under either reading, and a new Remark 2.9 explains why only "two adjacent levels" matters.
- **Proposition 5.3 (the period).** The old statement passed to a finite extension K₁ of K₀. That extension is not needed: a nonzero solution over ℂ already forces one over K₀. The number fields are now K₀ (abelian scheme, period) and K₁ (semistable model), instead of K₀, K₁, K₃.
- **Theorem 4.3 (weight one).** The integer D is absorbed into λ ∈ K⁺, and ξ₀ is any nonzero element with conjugate −ξ₀. The computation of iψ(X, X̄) is now written out (equation 4.4).
- **Lemma 2.6 (Christol's criterion)** is stated only for lower parameters that are non-integral or equal to 1, which is the range in which the paper uses it.
- **Lemma 2.10 (conjugate variation).** Removed an unnecessary "up to overall sign".
- **Theorem A** now says "not the diagonal of a rational function in fewer than three variables".
- **Remark 5.2** (new): the abelian scheme can be chosen with multiplication by an order of K. The examples in §8 quote this instead of asserting it without argument.
- **Corollary 6.6**: added the sentence that carries the identity from a sector to the punctured disc.
- **Proposition 6.2**: the monodromy theorem (Katz 1970) and the comparison of ℓ-adic and topological monodromy (SGA 7 II, Exp. XIV) are now cited where they are used.
- **Lemma 2.1(a)**: the proof was a one-line assertion; it is now complete.
- **Lemma 4.2**: the proof now covers degenerate flat hermitian forms.

### Claims removed or softened because I could not check them

- "Deligne credits essential surjectivity to Borel" (after Theorem 2.12). Removed.
- "Complex variations of Hodge structure were introduced by Simpson". Now "see Deligne (1987, §1) and Simpson (1988)".
- Pin-point citations to Lazarsfeld (was Theorem 3.1.21) and Jouanolou are now to sections (§3.1, §6).

### Notation

The old draft reused several letters. Each symbol now has one meaning: monodromy matrices T₀, T₁, T∞ (were h₀, h₁, h∞, clashing with the hermitian matrix h); polarizations Q_k (were h_k); sorted fractional parts a_i^(k), b^(k) (were A_i(k), B(k), clashing with the companion matrices A, B); abelian scheme 𝒜; base of the model W (was B₀); connection ∇ (was D, clashing with the divisor D); relative 1-form ϖ (was η, clashing with generic points); λ ∈ K⁺ (was η); pole orders ν_j (were k_i, clashing with k ∈ (ℤ/N)^×); complex conjugation is a bar throughout.

### Structure and style

- Abstract: one paragraph, under 200 words, no citations (was two paragraphs, 268 words).
- Plain-language summary kept where you asked for it, after the abstract and before the table of contents.
- Related work is now §1.5 of the Introduction rather than a separate section. The Introduction gained Table 1 (monodromy weights in the two realizations) and Figure 1 (flow of the proof).
- "Expansion at a node" and "Proof of Theorem A" are merged (§7). Sections are renumbered: Christol's example is §8.1, the main Hodge statement is Proposition 3.1, the weight-one theorem is Theorem 4.3. The script labels in `verify.py` match the new numbering.
- Sections 3, 4 and 5 open with their standing assumptions (the one in Section 5 also covers Sections 6 and 7). No sentence begins with a symbol.
- Bibliography: Bostan et al. is cited in its published form, *J. Phys. A* 46 (2013) 185202 (confirmed), with the unabridged arXiv:1211.6031 in a note. The Beukers–Heckman title no longer loses its capital F.
- The "Preprint draft, not refereed" footnote is gone from the title page. The same information is in the AI-tools statement and in the Limitations paragraph of the summary.

## What has not changed

The mathematical argument is the same as in v1.0. I found no failing step in this pass, but that is my own reading, not an independent one. **The proof has still not been checked by a specialist**, and you should treat the result as unverified until it has been.

## Points for an expert reader

In rough order of how much I would want a second opinion:

1. **Fedorov's theorem (Theorem 2.8)** applied with a repeated exponent, α = (0, 0, 1 − b). The paper states it with weak inequalities, as I read Fedorov's Theorem 1. Appendix A checks the output independently in 221,946 cases, but that count rests on two facts it calls standard and does not prove.
2. **Proposition 6.2**: unipotent topological monodromy ⇒ semistable reduction of the Jacobian (SGA 7 I, Exp. IX) ⇒ stable reduction of the curve (Deligne–Mumford, Theorem 2.4) ⇒ regular model with reduced special fibre.
3. **Lemma 6.4**: representing the class by a rational section of the relative dualizing sheaf with poles only along D and the special fibre.
4. **Theorem 4.3, Steps 2–4**: the sign bookkeeping. The script confirms the outcome for Christol's example only.
5. **Proposition 5.1**: spreading out and specializing the abelian scheme to a number field.
6. **Lemma 2.2**: quoted from Harder and Kramer-Miller (Lemma 3.2 of the arXiv version). The step from two algebraic to three rational variables rests on it.

## Citations I could not confirm

- **Harder & Kramer-Miller**: the IMRN volume and article number. The entry gives the journal, the year and arXiv:2504.10354.
- **Pin-point numbers carried over from v1.0** that I did not re-open in this pass: Beukers–Heckman Prop. 3.3, Thm 3.5 and Thm 4.8; Christol (2015) Theorem 33 and Corollary 30; Christol (1990) Theorem 12; Deligne (1987) Prop. 1.13(i); Dettweiler–Sabbah Theorem 2.4.1; Artin (1969) Theorem 1.10; Denef–Lipshitz Theorem 6.2 and Remark 6.4. Check these against the sources before submitting.
- The three review items I did not adopt in v1.0 still stand (Christol 2015 Cor. 30; the 2024 *Symmetry* paper I could not find; the Exposé number of Christol 1986/87).

## Before you submit

- **AI statement.** Reword it in your own voice. Most journals, and arXiv, also require the author to state that they take responsibility for the content. I did not write that sentence for you.
- **Plain-language summary.** arXiv accepts it as is. Many journals have no slot for an unnumbered section before the contents; be ready to move it to the end of the Introduction or drop it. The same goes for the table of contents, which journals usually remove.
- **Citation style.** The paper uses author–year citations, as you prefer. Most mathematics journals use numbers. To switch, replace `[authoryear,round]` by `[numbers]` in the `natbib` line and `plainnat` by `amsplain` or the journal's style.
- **Supplementary material.** Host the folder (GitHub, Zenodo) and put the link in the Data availability statement.
- **arXiv.** Suggested primary class math.NT, cross-lists math.AG and math.CO. The MSC codes on the title page are 33C20, 14D07; 13F25, 14K10, 32G20, 05A15.
- **arXiv abstract field** (plain text): replace the formulas by `3F2(a1,a2,a3; b,1; x)` and `3F2(1/9,4/9,5/9; 1/3,1; x)`.
