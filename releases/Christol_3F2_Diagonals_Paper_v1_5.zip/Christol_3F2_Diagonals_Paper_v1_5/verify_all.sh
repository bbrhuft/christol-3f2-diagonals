#!/bin/sh
# Default verification command for version 1.5 of
# "Christol's conjecture for non-resonant globally bounded 3F2(a1,a2,a3;b,1) series".
# Usage (from this folder):  sh verify_all.sh
# 1. checks the SHA-256 checksums of all files against SHA256SUMS;
# 2. runs supplementary/run_checks.sh (all checks, including a failure-injection test; ~5 min).
# Exit status 0 iff both steps succeed.  Requirements: Python >= 3.8, NumPy, sha256sum or shasum.
cd "$(dirname "$0")" || exit 1
echo "== checksums (SHA256SUMS)"
if command -v sha256sum >/dev/null 2>&1; then
  sha256sum --quiet -c SHA256SUMS || { echo "== FAILED: checksum mismatch"; exit 1; }
elif command -v shasum >/dev/null 2>&1; then
  shasum -a 256 --quiet -c SHA256SUMS || { echo "== FAILED: checksum mismatch"; exit 1; }
else
  echo "== FAILED: neither sha256sum nor shasum is available"; exit 1
fi
echo "checksums OK"
sh supplementary/run_checks.sh || { echo "== FAILED: supplementary/run_checks.sh"; exit 1; }
echo "== VERIFICATION COMPLETE: all checks passed"
