# Christol's conjecture for non-resonant globally bounded ₃F₂(a₁,a₂,a₃;b,1) series — version 1.4

David Jordan (Maynooth University). Referee revision of v1.3, 17 November 2026.

| File | Contents |
|---|---|
| `christol_w1.pdf` | the paper (38 pp.) |
| `christol_w1.tex`, `.bib`, `.bbl` | LaTeX source (amsart, natbib numeric) |
| `RESPONSE_TO_REFEREE.md` | point-by-point response, including what was changed |
| `VERIFICATION_LOG.md` | what was rerun or checked, and what was not |
| `DEPENDENCY_TABLE.md` | imported theorems, proved deductions, unresolved steps |
| `NOTES_FOR_AUTHOR.md` | private notes (not for submission) |
| `supplementary/` | scripts, stored outputs, search code, audits |
| `SHA256SUMS` | checksums of every file above |

## Verify

    sha256sum -c SHA256SUMS          # integrity
    cd supplementary
    sh run_checks.sh                 # all checks, about 4 min (Python >= 3.8, NumPy)
    sh run_checks.sh --quick         # about 15 s

## Build the paper

    latexmk -pdf christol_w1.tex
