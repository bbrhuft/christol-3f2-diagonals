"""Independent numerical test of the reconstructed family, using the note's own description of the cycle:
delta_j = lift of the polyline B_{5j} -> 0 -> B_{5j+1} on the sheet with v(0) ~ +i, returning on the other sheet,
transported from s=0 by tracking the branch points B_k(s). T^j gamma = delta_j + delta_{j+1}.
Periods of Omega_0..2 and eta_s are computed by Gauss-Legendre quadrature (u = B(1-tau^2) removes the
square-root endpoint singularity) at 30 digits, and compared with
   int_{T^j gamma} Omega_i = sum_l P_il(s) zeta^{5(l+1)j} J_{l+1}                       (Sections 2-4)
   int_{T^j gamma} eta_s   = s^2 H_1 zeta^j J_3 + (5/4) s^4 H_2 zeta^{2j} J_6 + s^8 H_4 zeta^{4j} J_5 / 32
and, on the ray arg s = 3 pi/14 (x<0), kappa*c*int_gamma eta_s with mpmath's 3F2."""
import sys, json, math, cmath
import numpy as np
from fractions import Fraction
from mpmath import mp, mpf, mpc, polyroots, findroot, beta as mbeta, gamma as mgamma, hyp3f2, exp, pi, gauss_quadrature
import mpmath
mp.dps = 30
I = mpc(0, 1)
zeta = exp(2*pi*I/7)
D = json.load(open(sys.argv[1]))
Fr = lambda d: {int(k): mpf(Fraction(v).numerator)/Fraction(v).denominator for k, v in d.items()}
hS, pS = Fr(D["h"]), {int(j): Fr(v) for j, v in D["p"].items()}
bS = [Fr(x) for x in D["b"]]
PS = [[Fr(x) for x in row] for row in D["P"]]
ev = lambda d, s: sum(c*s**k for k, c in d.items())

def cf(s):
    return ev(hS, s), {j: ev(pS[j], s) for j in range(1, 6)}

def cubic(u, h, p):
    z1 = [u*u, h]                       # z = A + B v (low->high)
    mul = lambda a, b: [sum(a[i]*b[k-i] for i in range(len(a)) if 0 <= k-i < len(b)) for k in range(len(a)+len(b)-1)]
    z2 = mul(z1, z1); z3 = mul(z2, z1)
    F = [mpc(0)]*4
    for k, c in enumerate(z3): F[k] += u*c
    F[0] += -1 + p[1]*u
    for k, c in enumerate(z1): F[k] += p[2]*c + p[3]*u*c
    for k, c in enumerate(z2): F[k] += p[4]*c + p[5]*u*c
    Phi = [-c for c in F]; Phi[2] += 1
    return Phi[::-1]

def vroots(u, h, p):
    c = cubic(u, h, p)
    if abs(c[0]) < mpf(10)**(-25):
        return polyroots(c[1:], maxsteps=200, extraprec=60)
    return polyroots(c, maxsteps=200, extraprec=60)

def Phiv(u, v, h, p):
    z = u*u + h*v
    return 2*v - h*(3*u*z*z + p[2] + p[3]*u + 2*p[4]*z + 2*p[5]*u*z)

def branch_points_np(h, p):
    sys.path.insert(0, '.')
    from curve_numeric import branch_points
    return branch_points(complex(h), {j: complex(p[j]) for j in p})

def refine(u0, h, p):
    r = vroots(mpc(u0), h, p)
    # pick the closest pair of roots
    pairs = [(abs(r[a]-r[b]), (r[a]+r[b])/2) for a in range(len(r)) for b in range(a+1, len(r))]
    v0 = min(pairs, key=lambda t: t[0])[1]
    f = lambda u, v: [cubic_eval(u, v, h, p), Phiv(u, v, h, p)]
    sol = findroot(f, (mpc(u0), v0))
    return sol[0]

def cubic_eval(u, v, h, p):
    c = cubic(u, h, p)
    return ((c[0]*v + c[1])*v + c[2])*v + c[3]

def track(s_target, nsteps):
    taus = np.linspace(0.03, 1.0, nsteps)
    h, p = cf(mpc(taus[0])*s_target)
    bp = branch_points_np(h, p)
    orig = [bp[np.argmin(abs(bp - complex(zeta**k)))] for k in range(7)]
    mind = [1e9]*7       # min distance of other branch points to V-path of delta_j
    for t in taus:
        h, p = cf(mpc(t)*s_target)
        bp = branch_points_np(h, p)
        new = [bp[np.argmin(abs(bp - o))] for o in orig]
        if len(set(np.round(new, 9))) < 7:
            raise RuntimeError("branch tracking collision; refine steps")
        jump = max(abs(np.array(new) - np.array(orig)))
        if jump > 0.05:
            raise RuntimeError(f"branch point jump {jump:.3f} at tau={t:.3f}; increase steps")
        orig = new
        for j in range(7):
            k1, k2 = (5*j) % 7, (5*j+1) % 7
            for q in bp:
                if min(abs(q-orig[k1]), abs(q-orig[k2])) < 1e-9:
                    continue
                for B in (orig[k1], orig[k2]):
                    # distance from q to segment [0,B]
                    tt = max(0, min(1, (q*np.conj(B)).real/abs(B)**2))
                    mind[j] = min(mind[j], abs(q - tt*B))
    return orig, mind

GLN = int(sys.argv[3]) if len(sys.argv) > 3 else 60

def gl_nodes(n):
    # Gauss-Legendre nodes/weights on [0,1] via numpy, then polish not needed for 1e-20 targets
    x, w = np.polynomial.legendre.leggauss(n)
    return [(mpf(xi)+1)/2 for xi in x], [mpf(wi)/2 for wi in w]

def leg(B, h, p, vstart_at0):
    """Integral over u = B(1-tau^2), tau in [0,1] (from B to 0) of Omega_i on the two sheets; returns
    (int_+ , int_-) each a list over i=0,1,2. Sheet '+' is the root continuing to vstart_at0 at u=0."""
    xs, ws = gl_nodes(GLN)
    order = sorted(range(GLN), key=lambda k: -xs[k])      # march from tau=1 (u=0) down to 0
    fine = sorted(set([float(xs[k]) for k in order] + list(np.linspace(1, 0.0005, 400))), reverse=True)
    vplus = vstart_at0
    r0 = vroots(mpc(0), h, p)
    vminus = min(r0, key=lambda v: abs(v + vstart_at0))
    tot_p, tot_m = [mpc(0)]*3, [mpc(0)]*3
    node_set = {float(xs[k]): k for k in range(GLN)}
    for tf in fine:
        t = mpf(tf)
        if tf in node_set:
            t = xs[node_set[tf]]
        u = B*(1 - t*t)
        r = vroots(u, h, p)
        vplus = min(r, key=lambda v: abs(v - vplus))
        vminus = min(r, key=lambda v: abs(v - vminus))
        if tf in node_set:
            k = node_set[tf]
            du = -2*B*t
            for sgn, v, tot in ((1, vplus, tot_p), (-1, vminus, tot_m)):
                den = Phiv(u, v, h, p)
                N = [1, u, u*u + h*v]
                for i in range(3):
                    tot[i] += ws[k]*2*N[i]*du/den
    return tot_p, tot_m

def delta_integrals(s, B1, B2):
    h, p = cf(s)
    r0 = vroots(mpc(0), h, p)
    vp = min(r0, key=lambda v: abs(v - I))
    a_p, a_m = leg(B1, h, p, vp)      # B1 -> 0
    b_p, b_m = leg(B2, h, p, vp)      # B2 -> 0 (reverse sign for 0 -> B2)
    # forward on + : B1->0->B2 ; back on - : B2->0->B1
    return [(a_p[i] - b_p[i]) - (a_m[i] - b_m[i]) for i in range(3)]

def Jq(q):
    return (1+zeta**(5*q))*2*(zeta**q-1)/(7*I)*mbeta(mpf(q)/7, mpf(1)/2)

def Hk(k, s, nmax=12):
    t7 = -s**14/64; tot = 0; d = mpf(1)
    for n in range(nmax):
        tot += d*t7**n
        dd = k + 7*n
        d *= -mpf(dd)**2*(dd+mpf(7)/2)/((dd+6)*(dd+5)*(dd+3))
    return tot

def Ck(k):
    U = [1, 2, 4]
    val = mgamma(mpf(1)/2)/(mgamma(mpf(1)/2-mpf(k)/7)*mgamma(1-mpf(k)/7))
    for j in U:
        if j != k:
            val *= mgamma(mpf(j-k)/7)/mgamma(mpf(j)/7)
    return val

def run(s_target, nsteps=300):
    s_target = mpc(s_target)
    orig, mind = track(complex(s_target), nsteps)
    print(f"s = {mpmath.nstr(s_target, 6)}, |s^14| = {float(abs(s_target)**14):.2e}; min distance of other branch points to each V-path over the deformation:",
          ", ".join(f"{m:.3f}" for m in mind))
    h, p = cf(s_target)
    Bs = [refine(o, h, p) for o in orig]
    dels = [delta_integrals(s_target, Bs[(5*j) % 7], Bs[(5*j+1) % 7]) for j in range(7)]
    P = [[ev(PS[i][l], s_target) for l in range(6)] for i in range(3)]
    b = [ev(bS[i], s_target) for i in range(3)]
    err_om, err_eta = mpf(0), mpf(0)
    for j in range(7):
        gam = [dels[j][i] + dels[(j+1) % 7][i] for i in range(3)]
        pred = [sum(P[i][l]*zeta**(5*(l+1)*j)*Jq(l+1) for l in range(6)) for i in range(3)]
        err_om = max(err_om, max(abs(gam[i]-pred[i])/abs(pred[i]) for i in range(3)))
        eta = s_target**2*sum(b[i]*gam[i] for i in range(3))
        sp = s_target
        eta_pred = sp**2*Hk(1, sp)*zeta**j*Jq(3) + mpf(5)/4*sp**4*Hk(2, sp)*zeta**(2*j)*Jq(6) + sp**8/32*Hk(4, sp)*zeta**(4*j)*Jq(5)
        err_eta = max(err_eta, abs(eta-eta_pred)/abs(eta_pred))
        if j == 0:
            eta0 = eta
    print(f"   max rel error of P (3 rows x 7 cycles): {mpmath.nstr(err_om, 3)};  eta_s periods vs Frobenius: {mpmath.nstr(err_eta, 3)}")
    c = -mpf(2)**(-mpf(6)/7)*zeta**2
    kappa = Ck(1)/Jq(3)
    x = 64/s_target**14
    if abs(mpmath.im(x)) < 1e-12*abs(x) and mpmath.re(x) < 0:
        S7 = hyp3f2(mpf(1)/7, mpf(2)/7, mpf(4)/7, mpf(1)/2, 1, mpmath.re(x))
        print(f"   x = {mpmath.nstr(mpmath.re(x), 8)}: kappa*c*int_gamma eta = {mpmath.nstr(kappa*c*eta0, 20)} ; 3F2 = {mpmath.nstr(S7, 20)}")

def run_gamma0(s_target, nsteps=400):
    s_target = mpc(s_target)
    orig, mind = track(complex(s_target), nsteps)
    h, p = cf(s_target)
    Bs = [refine(o, h, p) for o in orig]
    d0 = delta_integrals(s_target, Bs[0], Bs[1])      # delta_0: B_0 -> 0 -> B_1
    d1 = delta_integrals(s_target, Bs[5], Bs[6])      # delta_1: B_5 -> 0 -> B_6
    gam = [d0[i] + d1[i] for i in range(3)]
    b = [ev(bS[i], s_target) for i in range(3)]
    eta = s_target**2*sum(b[i]*gam[i] for i in range(3))
    c = -mpf(2)**(-mpf(6)/7)*zeta**2
    kappa = Ck(1)/Jq(3)
    x = mpmath.re(64/s_target**14)
    S7 = hyp3f2(mpf(1)/7, mpf(2)/7, mpf(4)/7, mpf(1)/2, 1, x)
    val = kappa*c*eta
    print(f"|s|={mpmath.nstr(abs(s_target),3)}  x={mpmath.nstr(x,8)}  path margins (delta_0, delta_1) = {mind[0]:.3f}, {mind[1]:.3f}")
    print(f"   kappa*c*int_gamma eta_s = {mpmath.nstr(val, 22)}")
    print(f"   3F2(1/7,2/7,4/7;1/2,1;x) = {mpmath.nstr(S7, 22)}   rel.diff = {mpmath.nstr(abs(val-S7)/abs(S7), 3)}")

if __name__ == "__main__":
    mode = sys.argv[4] if len(sys.argv) > 4 else "all"
    for st in sys.argv[2].split(','):
        (run_gamma0 if mode == "gamma0" else run)(complex(st))
