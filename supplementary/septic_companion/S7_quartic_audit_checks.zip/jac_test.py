from reconstruct import periods
from flint import fmpq
# first variation in D: h = s (formal), p = 0, read order s^2
P, ok = periods({1: fmpq(1)}, {1: {}, 2: {}, 3: {}, 4: {}, 5: {}}, 2)
print("dP/dD rows (order s^2):", [[P[i][j].get(2, 0) for j in range(6)] for i in range(3)], "res ok", ok)
print("order s^1 (should vanish):", [[P[i][j].get(1, 0) for j in range(6)] for i in range(3)])
for l in range(1, 6):
    p = {k: {} for k in range(1, 6)}; p[l] = {1: fmpq(1)}
    P, ok = periods({}, p, 1)
    print(f"dP/dp{l}:", [[P[i][j].get(1, 0) for j in range(6)] for i in range(3)])
