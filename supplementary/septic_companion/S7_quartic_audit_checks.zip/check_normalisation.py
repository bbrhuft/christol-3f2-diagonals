"""Independent checks of Sections 2-3 of the S7 quartic note (normalisation identities)."""
from mpmath import mp, mpf, mpc, gamma, beta, exp, pi, sin, hyp3f2, quad, sqrt, matrix, inverse, nstr, polyroots
mp.dps = 50
I = mpc(0, 1)
zeta = exp(2*pi*I/7)

# --- Frobenius series H_k (recursion as stated in the note) ---
def H(k, t, N=400):
    d, tot, term = None, mpf(0), mpf(1)
    for n in range(N):
        tot += term * t**(7*n)
        dd = k + 7*n
        term *= -mpf(dd)**2*(dd+mpf(7)/2)/((dd+6)*(dd+5)*(dd+3))
    return tot

def C(k):
    U = [1, 2, 4]
    val = gamma(mpf(1)/2)/(gamma(mpf(1)/2-mpf(k)/7)*gamma(1-mpf(k)/7))
    for j in U:
        if j != k:
            val *= gamma(mpf(j-k)/7)/gamma(mpf(j)/7)
    return val

# 1. Connection formula S7 = sum C_k y_k on x<0
for x in [mpf(-3), mpf(-1.7), mpf(-25)]:
    t = (-x)**(-mpf(1)/7)
    lhs = hyp3f2(mpf(1)/7, mpf(2)/7, mpf(4)/7, mpf(1)/2, 1, x)
    rhs = sum(C(k)*t**k*H(k, t) for k in (1, 2, 4))
    print(f"x={nstr(x,4)}: S7={nstr(lhs,25)}  sum C_k y_k={nstr(rhs,25)}  diff={nstr(abs(lhs-rhs),3)}")

# 2. J_q closed form vs direct integration along delta (1 -> 0 -> zeta on sheet v(0)=i, back on -sheet)
def Jformula(q):
    return (1+zeta**(5*q))*2*(zeta**q-1)/(7*I)*beta(mpf(q)/7, mpf(1)/2)

def Jdirect(q):
    # radial legs: v = i*sqrt(1-r^7) on both legs (sheet continuous through u=0)
    f = lambda r: r**(q-1)/(I*sqrt(1-r**7))
    leg = quad(f, [0, 1])
    delta = 2*(-leg + zeta**q*leg)        # 1->0 then 0->zeta, doubled by the return on the opposite sheet
    return delta*(1+zeta**(5*q))           # (1+T_*): T^* e_{q-1} = zeta^{5q} e_{q-1}

for q in range(1, 7):
    print(f"q={q}: |Jformula-Jdirect| = {nstr(abs(Jformula(q)-Jdirect(q)),3)}")

# 3. lambda, mu identities
c = -mpf(2)**(-mpf(6)/7)*zeta**2
lam_closed, mu_closed = 5/(4*c), 1/(32*c**3)
lam = (C(2)/Jformula(6))/(C(1)/Jformula(3))
mu = (C(4)/Jformula(5))/(C(1)/Jformula(3))
print("lambda ratio vs 5/(4c):   ", nstr(abs(lam-lam_closed), 3), " vs -5*2^(-8/7)zeta^-2:", nstr(abs(lam_closed+5*mpf(2)**(-mpf(8)/7)*zeta**-2), 3))
print("mu ratio vs 1/(32c^3):    ", nstr(abs(mu-mu_closed), 3), " vs -2^(-17/7)zeta:", nstr(abs(mu_closed+mpf(2)**(-mpf(17)/7)*zeta), 3))
print("c^7 =", nstr(c**7, 20))

# 4. cyclotomic factors
S = lambda j: sin(pi*j/7)
for (k, q, d, target) in [(2, 6, 2, zeta**-2), (4, 5, 3, zeta)]:
    val = (zeta**3-1)/(zeta**q-1)*(S(1)/S(d))**2*(1+zeta)/(1+zeta**k)
    print(f"cyclotomic (k,q,d)=({k},{q},{d}): |val-target| = {nstr(abs(val-target),3)}")

# 5. Consistency: intersection row + periods => cup-product pattern (zero unless i+j=5, ratios 1/5:1/3:1)
r = [0, 0, 1, 1, -1, -1, 0]
M = matrix(6, 6)
for a in range(6):
    for b in range(6):
        M[a, b] = r[(b-a) % 7]
print("det Gram(gamma translates) =", nstr(mp.det(M), 15))
# delta translates: a_3=1, a_4=-1
Md = matrix(6, 6)
for a in range(6):
    for b in range(6):
        Md[a, b] = {3: 1, 4: -1}.get((b-a) % 7, 0)
print("det Gram(delta translates) =", nstr(mp.det(Md), 15))
Minv = inverse(M)
per = [[zeta**(5*(i+1)*k)*Jformula(i+1) for k in range(6)] for i in range(6)]
cup = [[sum(per[i][a]*Minv[b, a]*per[j][b] for a in range(6) for b in range(6)) for j in range(6)] for i in range(6)]
ref = cup[2][3]
print("cup-product matrix / <e2,e3> (should be antidiagonal 1/5,1/3,1,-1,-1/3,-1/5):")
for i in range(6):
    print("  ", [nstr((cup[i][j]/ref).real, 6) if abs(cup[i][j]/ref) > 1e-30 else 0 for j in range(6)])
print("max imag part of normalised cup:", nstr(max(abs((cup[i][j]/ref).imag) for i in range(6) for j in range(6)), 3))
print("<e2,e3> =", nstr(ref, 20), " vs 2*pi*i*4 =", nstr(2*pi*I*4, 20))
