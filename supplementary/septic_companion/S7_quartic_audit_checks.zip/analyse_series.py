"""Structure of the exact series: weights, denominators, growth in X = 1/x = s^14/64."""
import re, sys
from fractions import Fraction
from sympy import factorint
txt = open(sys.argv[1]).read().split("=== N")[-1]
def parse(name):
    line = [l for l in txt.splitlines() if l.startswith(name + " ")][0]
    return {int(k): Fraction(v) for v, k in re.findall(r"\(([-0-9/]+)\)\*s\^(\d+)", line)}
ser = {"h": parse("h")}
for j in range(1, 6):
    ser[f"p{j}"] = parse(f"p{j}")
# D = h^2
h = ser["h"]; N = max(h)
D = {}
for a, x in h.items():
    for b, y in h.items():
        if a + b <= N + 1:
            D[a+b] = D.get(a+b, 0) + x*y
ser["D=h^2"] = D
primes = set()
for name, S in ser.items():
    ks = sorted(S)
    e0 = ks[0]
    assert all((k - e0) % 14 == 0 for k in ks), name
    for v in S.values():
        primes |= set(factorint(v.denominator))
    # coefficients in X = s^14/64: S = s^e0 * sum c_n (64 X)^n  -> a_n = c_n * 64^n
    a = [S[e0 + 14*n]*64**n for n in range((max(ks)-e0)//14 + 1)]
    lead = a[0]
    rat = [float(a[n+1]/a[n]) for n in range(len(a)-1) if a[n] != 0]
    print(f"{name:6s} = s^{e0} * ({lead}) * [1 + sum a_n X^n],  a_n/a_(n-1) =", ", ".join(f"{r:.2f}" for r in rat))
print("primes in denominators:", sorted(primes))

# Pade analysis in X for a few functions
import mpmath
mpmath.mp.dps = 40
for name in ["D=h^2", "p3", "p2", "p1"]:
    S = ser[name]; ks = sorted(S); e0 = ks[0]
    a = [mpmath.mpf(S[e0+14*n].numerator)/S[e0+14*n].denominator*64**n for n in range((max(ks)-e0)//14+1)]
    L = len(a) - 1
    for (m, n) in [(L//2, L - L//2)]:
        p, q = mpmath.pade(a, m, n)
        zq = mpmath.polyroots(q[::-1], maxsteps=200, extraprec=100) if n > 0 else []
        print(f"{name}: Pade[{m}/{n}] in X: poles at x = 1/X:", ", ".join(mpmath.nstr(1/z, 5) for z in zq))
    vals = [mpmath.nstr(sum(c*X**k for k, c in enumerate(a)), 6) for X in (mpmath.mpf(-1)/10, mpmath.mpf(-1)/7)]
    print(f"   partial sums at x=-10, -7: {vals}")
