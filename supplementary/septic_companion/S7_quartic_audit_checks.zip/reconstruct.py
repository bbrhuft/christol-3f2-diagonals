"""Independent exact re-implementation of the curve reconstruction in Section 4 of the S7 note.

Method (deliberately different from the note's G^l residue expansion):
  * solve v^2 = F_p(1,u,u^2+h v) for the root v = V0 + y near V0 = sqrt(u^7-1) by order-by-order Hensel
    lifting in s, inside the ring Q[u,V0,1/V0]/(V0^2-u^7+1) with basis u^j V0^m (0<=j<=6, m in Z);
  * form Omega_i/du = 2 N_i / Phi_v with Phi_v = 2v - h F_z exactly;
  * reduce u^j V0^m du to the basis e_0..e_5 (odd m) and check that even-m (rational) parts have zero residues;
  * solve the six graph equations for h, p_1..p_5 by constant-Jacobian iteration;
  * check the three graph equations that are NOT imposed (Lagrangian consistency) and recover b_i.
All arithmetic is exact (python-flint fmpq).
"""
import sys, time
from flint import fmpq

ZERO = fmpq(0)


def rmul(X, Y):
    """Multiply two ring elements (dicts {(j,m): coeff}) using u^7 = V0^2 + 1."""
    out = {}
    for (a, m), x in X.items():
        for (b, n), y in Y.items():
            c = x * y
            j, k = a + b, m + n
            if j >= 7:
                j -= 7
                out[(j, k + 2)] = out.get((j, k + 2), ZERO) + c
            out[(j, k)] = out.get((j, k), ZERO) + c
    return {key: v for key, v in out.items() if v != 0}


def radd(X, Y, c=fmpq(1)):
    out = dict(X)
    for key, v in Y.items():
        out[key] = out.get(key, ZERO) + c * v
    return {key: v for key, v in out.items() if v != 0}


def rscale(X, c):
    return {key: c * v for key, v in X.items()} if c != 0 else {}


def vshift(X, d):
    return {(j, m + d): v for (j, m), v in X.items()}


# ---------- scalar truncated series: dict order -> fmpq ----------
def smul(A, B, N):
    out = {}
    for i, a in A.items():
        for j, b in B.items():
            if i + j <= N:
                out[i + j] = out.get(i + j, ZERO) + a * b
    return {k: v for k, v in out.items() if v != 0}


# ---------- ring-valued series: list over orders of ring elements ----------
def poly_u(coeffs):
    """coeffs: dict j -> scalar series; returns ring-series (list of dicts) as function of order."""
    return coeffs


def build_g(h, p, N):
    """G(u,v) = g0 + g1 v + g2 v^2 + g3 v^3 with ring-series coefficients (lists of ring dicts)."""
    h2, h3 = smul(h, h, N), smul(smul(h, h, N), h, N)
    ph = {j: smul(p[j], h, N) for j in p}
    ph2 = {j: smul(p[j], h2, N) for j in p}

    def mk(terms):  # terms: list of (scalar series, u-power, multiplier)
        S = [dict() for _ in range(N + 1)]
        for ser, upow, mult in terms:
            for n, c in ser.items():
                if n <= N:
                    key = (upow, 0)
                    S[n][key] = S[n].get(key, ZERO) + mult * c
        return S

    g0 = mk([(p[1], 1, 1), (p[2], 2, 1), (p[3], 3, 1), (p[4], 4, 1), (p[5], 5, 1)])
    g1 = mk([(h, 5, 3), (ph[2], 0, 1), (ph[3], 1, 1), (ph[4], 2, 2), (ph[5], 3, 2)])
    g2 = mk([(h2, 3, 3), (ph2[4], 0, 1), (ph2[5], 1, 1)])
    g3 = mk([(h3, 1, 1)])
    return [g0, g1, g2, g3]


def conv_order(A, B, n, amin=0, bmin=0):
    """[s^n] of A*B for ring-series lists A, B."""
    out = {}
    for a in range(amin, n - bmin + 1):
        if A[a] and B[n - a]:
            out = radd(out, rmul(A[a], B[n - a]))
    return out


def periods(h, p, N):
    """Return P[i][j] as scalar series (dict order->fmpq) to order N, plus residue-check status."""
    g = build_g(h, p, N)
    V0 = {(0, 1): fmpq(1)}
    one = {(0, 0): fmpq(1)}
    P0 = [one] + [dict() for _ in range(N)]
    P1 = [V0] + [dict() for _ in range(N)]
    P2 = [rmul(V0, V0)] + [dict() for _ in range(N)]
    P3 = [rmul(P2[0], V0)] + [dict() for _ in range(N)]
    Ppow = [P0, P1, P2, P3]
    y = [dict() for _ in range(N + 1)]
    for n in range(1, N + 1):
        Gn = {}
        for k in range(4):
            Gn = radd(Gn, conv_order(g[k], Ppow[k], n, amin=1))
        y2 = conv_order(y, y, n, amin=1, bmin=1)
        y[n] = rscale(vshift(radd(Gn, y2, fmpq(-1)), -1), fmpq(1, 2))
        P1[n] = y[n]
        P2[n] = conv_order(P1, P1, n)
        P3[n] = conv_order(P2, P1, n)
    # Phi_v = 2 P1 - (g1 + 2 g2 P1 + 3 g3 P2) = 2 V0 (1 + eps)
    Phiv = [dict() for _ in range(N + 1)]
    for n in range(N + 1):
        t = rscale(P1[n], fmpq(2))
        t = radd(t, g[1][n], fmpq(-1))
        t = radd(t, conv_order(g[2], P1, n, amin=1), fmpq(-2))
        t = radd(t, conv_order(g[3], P2, n, amin=1), fmpq(-3))
        Phiv[n] = t
    eps = [dict()] + [rscale(vshift(Phiv[n], -1), fmpq(1, 2)) for n in range(1, N + 1)]
    Q = [one] + [dict() for _ in range(N)]
    for n in range(1, N + 1):
        acc = {}
        for a in range(1, n + 1):
            if eps[a] and Q[n - a]:
                acc = radd(acc, rmul(eps[a], Q[n - a]))
        Q[n] = rscale(acc, fmpq(-1))
    hP1 = [dict() for _ in range(N + 1)]
    for n in range(N + 1):
        for a, c in h.items():
            if 1 <= a <= n and P1[n - a]:
                hP1[n] = radd(hP1[n], rscale(P1[n - a], c))
    Nn = [[one] + [dict() for _ in range(N)],
          [{(1, 0): fmpq(1)}] + [dict() for _ in range(N)],
          [radd({(2, 0): fmpq(1)}, hP1[0])] + [hP1[n] for n in range(1, N + 1)]]
    P = [[dict() for _ in range(6)] for _ in range(3)]
    res_ok = True
    for i in range(3):
        for n in range(N + 1):
            form = vshift(conv_order(Nn[i], Q, n), -1)   # Omega_i/du at order n
            vec, even = classify(form)
            for jj in range(6):
                if vec[jj] != 0:
                    P[i][jj][n] = vec[jj]
            if not residues_vanish(even):
                res_ok = False
    return P, res_ok


# ---------- cohomology class map ----------
_cache = {}


def red_minus1(J):
    """[u^J du/V0] in basis e_0..e_5 (J >= 0)."""
    key = ('m1', J)
    if key in _cache:
        return _cache[key]
    if J <= 5:
        v = [ZERO] * 6
        v[J] = fmpq(1)
    elif J == 6:
        v = [ZERO] * 6
    else:
        w = red_minus1(J - 7)
        f = fmpq(2 * (J - 6), 2 * J - 5)
        v = [f * x for x in w]
    _cache[key] = v
    return v


def binom_int(n, k):
    from math import comb
    return comb(n, k)


def red(j, m):
    """[u^j V0^m du], m odd."""
    key = (j, m)
    if key in _cache:
        return _cache[key]
    if m == -1:
        v = red_minus1(j)
    elif m >= 1:
        e = (m + 1) // 2          # u^j (u^7-1)^e / V0
        v = [ZERO] * 6
        for r in range(e + 1):
            c = binom_int(e, r) * (-1) ** (e - r)
            w = red_minus1(j + 7 * r)
            v = [a + c * b for a, b in zip(v, w)]
    else:
        l = (-m - 1) // 2         # m = -(2l+1), l >= 1
        f = fmpq(2 * (j + 1), 7 * (2 * l - 1)) - 1
        w = red(j, m + 2)
        v = [f * x for x in w]
    _cache[key] = v
    return v


def classify(form):
    vec = [ZERO] * 6
    even = {}
    for (j, m), c in form.items():
        if m % 2:
            w = red(j, m)
            vec = [a + c * b for a, b in zip(vec, w)]
        elif m < 0:
            even[(j, m)] = c
    return vec, even


_rescache = {}


def rho(j, r):
    """Res_{tau=0} (1+tau)^j / ((1+tau)^7-1)^r dtau (the residue at u=1 of u^j du/(u^7-1)^r)."""
    key = (j, r)
    if key in _rescache:
        return _rescache[key]
    # (1+tau)^7 - 1 = 7 tau (1 + q(tau)); need coefficient of tau^(r-1) in (1+tau)^j (1+q)^(-r) / 7^r
    M = r  # series length needed
    from math import comb
    q = [fmpq(comb(7, k + 1), 7) for k in range(0, M + 1)]  # (1+tau)^7-1 = 7 tau * sum q_k tau^k, q_0 = 1
    # inverse power (sum q_k tau^k)^(-r) via log-free recursion: compute S = (sum q)^r then invert
    S = [fmpq(1)] + [ZERO] * M
    for _ in range(r):
        S = [sum((S[a] * q[n - a] for a in range(n + 1)), ZERO) for n in range(M + 1)]
    inv = [fmpq(1)] + [ZERO] * M
    for n in range(1, M + 1):
        inv[n] = -sum((S[a] * inv[n - a] for a in range(1, n + 1)), ZERO)
    num = [fmpq(comb(j, k)) for k in range(M + 1)]
    coeff = sum((num[a] * inv[r - 1 - a] for a in range(r)), ZERO)
    val = coeff / fmpq(7) ** r
    _rescache[key] = val
    return val


def residues_vanish(even):
    # residue at alpha = zeta^k is sum_j alpha^(j+1) * sum_r c_{j,-2r} rho(j,r); characters j+1 mod 7 independent
    tot = {}
    for (j, m), c in even.items():
        r = -m // 2
        tot[j] = tot.get(j, ZERO) + c * rho(j, r)
    return all(v == 0 for v in tot.values())


# ---------- hypergeometric data ----------
def Hser(k, N):
    """H_k as series in s: sum d_kn (t^7)^n, t^7 = -s^14/64."""
    out, d, n = {}, fmpq(1), 0
    while 14 * n <= N:
        out[14 * n] = d * fmpq(-1, 64) ** n
        dd = k + 7 * n
        d = d * (-fmpq(dd) ** 2 * (dd + fmpq(7, 2)) / ((dd + 6) * (dd + 5) * (dd + 3)))
        n += 1
    return out


def sinv(A, N):
    """Inverse of a scalar series with A[0] != 0."""
    a0 = A[0]
    out = {0: 1 / a0}
    for n in range(1, N + 1):
        acc = sum((A.get(k, ZERO) * out.get(n - k, ZERO) for k in range(1, n + 1)), ZERO)
        if acc != 0:
            out[n] = -acc / a0
    return out


def sadd(A, B, c=fmpq(1)):
    out = dict(A)
    for k, v in B.items():
        out[k] = out.get(k, ZERO) + c * v
    return {k: v for k, v in out.items() if v != 0}


def shiftser(A, d):
    return {k + d: v for k, v in A.items()}


def solve(N, verbose=True):
    H1, H2, H4 = Hser(1, N), Hser(2, N), Hser(4, N)
    iH1 = sinv(H1, N)
    a = {k: fmpq(5, 4) * v for k, v in shiftser(smul(H2, iH1, N), 2).items() if k <= N}
    b = {k: fmpq(1, 32) * v for k, v in shiftser(smul(H4, iH1, N), 6).items() if k <= N}
    h = {1: fmpq(1)}
    p = {1: {}, 2: {}, 3: {2: fmpq(-1, 2)}, 4: {}, 5: {}}
    # inverse of the 2x2 block [[-1/14, 3/14], [-3/14, -3/28]] acting on (dp3, dD)
    import sympy as sp
    Jb = sp.Matrix([[sp.Rational(-1, 14), sp.Rational(3, 14)], [sp.Rational(-3, 14), sp.Rational(-3, 28)]]).inv()
    Jb = [[fmpq(int(sp.fraction(Jb[i, j])[0]), int(sp.fraction(Jb[i, j])[1])) for j in range(2)] for i in range(2)]
    diag = {1: fmpq(-1, 14), 2: fmpq(-1, 14), 4: fmpq(-3, 14), 5: fmpq(-5, 14)}
    for it in range(200):
        t0 = time.time()
        P, res_ok = periods(h, p, N)
        def g(i, j): return P[i][j]
        E = {
            'E1': sadd(sadd(g(0, 3), smul(a, g(0, 0), N), fmpq(-1, 5)), smul(b, g(0, 1), N), fmpq(-1, 3)),
            'E2': sadd(g(1, 4), smul(b, g(1, 2), N), fmpq(-1)),
            'E3': sadd(sadd(g(2, 3), smul(a, g(2, 0), N), fmpq(-1, 5)), smul(b, g(2, 1), N), fmpq(-1, 3)),
            'E4': sadd(sadd(g(1, 3), smul(a, g(1, 0), N), fmpq(-1, 5)), smul(b, g(1, 1), N), fmpq(-1, 3)),
            'E5': sadd(g(0, 4), smul(b, g(0, 2), N), fmpq(-1)),
            'E6': sadd(g(0, 5), smul(a, g(0, 2), N), fmpq(-1)),
        }
        orders = [min(v) for v in E.values() if v]
        if verbose:
            print(f"iter {it}: lowest residual order {min(orders) if orders else None}, residues ok={res_ok}, {time.time()-t0:.1f}s", flush=True)
        if not orders:
            break
        n = min(orders)
        R = {k: v.get(n, ZERO) for k, v in E.items()}
        # 2x2 block: E1 = -1/14 dp3 + 3/14 dD ; E2 = -3/14 dp3 - 3/28 dD
        dp3 = -(Jb[0][0] * R['E1'] + Jb[0][1] * R['E2'])
        dD = -(Jb[1][0] * R['E1'] + Jb[1][1] * R['E2'])
        if dp3 != 0:
            p[3][n] = p[3].get(n, ZERO) + dp3
        if dD != 0:
            h[n - 1] = h.get(n - 1, ZERO) + dD / 2
        for key, l in (('E3', 1), ('E4', 2), ('E5', 4), ('E6', 5)):
            if R[key] != 0:
                p[l][n] = p[l].get(n, ZERO) - R[key] / diag[l]
    # unimposed graph equations (Lagrangian consistency)
    P, res_ok = periods(h, p, N)
    def g(i, j): return P[i][j]
    extra = {
        'P24-bP22': sadd(g(2, 4), smul(b, g(2, 2), N), fmpq(-1)),
        'P15-aP12': sadd(g(1, 5), smul(a, g(1, 2), N), fmpq(-1)),
        'P25-aP22': sadd(g(2, 5), smul(a, g(2, 2), N), fmpq(-1)),
    }
    # b_i: d = third row of inverse of [P_ij]_{i,j<3}; b_i = H1 d_i
    import sympy as sp
    s = sp.symbols('s')
    def tosym(D): return sum(sp.Rational(int(v.p), int(v.q)) * s ** k for k, v in D.items())
    M3 = sp.Matrix(3, 3, lambda i, j: tosym(g(i, j)))
    # series inverse via Neumann: M3 = I + X
    X = M3 - sp.eye(3)
    inv = sp.eye(3)
    term = sp.eye(3)
    for _ in range(N):
        term = (-term * X).applyfunc(lambda e: sp.series(sp.expand(e), s, 0, N + 1).removeO() if e != 0 else 0)
        if term == sp.zeros(3):
            break
        inv = inv + term
    drow = inv[2, :]
    H1s = tosym(H1)
    bcoef = [sp.expand(sp.series(sp.expand(H1s * drow[i]), s, 0, N + 1).removeO()) for i in range(3)]
    return h, p, a, b, extra, bcoef, res_ok, P


if __name__ == '__main__':
    N = int(sys.argv[1]) if len(sys.argv) > 1 else 30
    t0 = time.time()
    h, p, a, b, extra, bcoef, res_ok, P = solve(N)
    fmt = lambda D: ' + '.join(f"({v})*s^{k}" for k, v in sorted(D.items()))
    print(f"\n=== N = {N} (all series exact through s^{N}); total {time.time()-t0:.1f}s ===")
    print("h  =", fmt(h))
    for j in range(1, 6):
        print(f"p{j} =", fmt(p[j]))
    for i in range(3):
        print(f"b{i} =", bcoef[i])
    print("residue (second-kind) checks all passed:", res_ok)
    for k, v in extra.items():
        print(f"unimposed graph equation {k}: residual = {fmt(v) if v else 0}")
