"""Eisenstein-type test: for an algebraic power series, denominators are bounded by A^n.
Report 2- and 7-adic valuations of the denominators of the coefficient of sigma^n (sigma = s^14) and of the
numerators' primes, for each coefficient function, through s^100."""
import re, sys
from fractions import Fraction
from sympy import factorint, multiplicity
txt = open(sys.argv[1]).read().split("=== N")[-1]
def parse(name):
    line = [l for l in txt.splitlines() if l.startswith(name + " ")][0]
    return {int(k): Fraction(v) for v, k in re.findall(r"\(([-0-9/]+)\)\*s\^(\d+)", line)}
for name in ["h", "p1", "p2", "p3", "p4", "p5"]:
    S = parse(name); ks = sorted(S)
    v2 = [multiplicity(2, S[k].denominator) for k in ks]
    v7 = [multiplicity(7, S[k].denominator) for k in ks]
    print(f"{name}: v2(den) = {v2}; v7(den) = {v7}")
