# Independent verification bundle for "A marked genus-three quartic germ for the septic hypergeometric period" (21 Nov 2026)

Requirements: Python 3.10+, `python-flint`, `sympy`, `mpmath`, `numpy` (`pip install python-flint sympy mpmath numpy`).
None of these scripts reuse `quartic.py` or `marking.py` from the note; the method in `reconstruct.py` differs from the note's.

| Script | What it checks | Result (saved output) |
|---|---|---|
| `check_normalisation.py` | Sections 2–3: connection formula S7 = Σ C_k y_k on x<0 (vs mpmath 3F2); closed form for J_q vs direct integration over δ; λ = 5/(4c), μ = 1/(32c³); cyclotomic factors; Gram determinants; cup-product pattern from intersection row + periods | all agree to 1e-27–1e-51; both Gram dets = 1; cup products antidiagonal 1/5 : 1/3 : 1 (`check_normalisation.txt`) |
| `check_lattice.py` | Section 5: H Hermitian and A,B-invariant; A − B rank 1; im(B²−I) = ⟨(−1,0,1)⟩; signature of H; J(v*, A^j v*) row; Gram det; A + A² + A⁴ = w·I | all true; row = (0,0,1,1,−1,−1,0); det = 1; signature (1,2) (`check_lattice.txt`) |
| `jac_test.py` | First variations ∂P/∂D, ∂P/∂p_l | reproduces the note's 2×2 block and the four diagonal entries (`jac_test.txt`) |
| `reconstruct.py N` | Section 4 rebuilt from scratch: Hensel lift of v in Q[u,V0^±1]/(V0²−u⁷+1), exact Ω_i = 2N_i du/Φ_v, reduction to e_0..e_5, residue check on rational parts, constant-Jacobian solve of the six graph equations, check of the three *unimposed* graph equations, recovery of b_i | all initial terms in the note reproduced exactly; exact through s^100 (≈7 orders in 1/x) in ~6 min; unimposed equations vanish identically (`reconstruct_N100.txt`) |
| `dump_series.py N` | writes h, p_j, b_i and the full 3×6 period matrix P_ij(s) as exact rationals | `series_N100.json` |
| `period_check_v.py` | Fully independent numerics on the actual curve: integrates Ω_0..2 and η_s over the transported cycles T^jγ (note's own V-path description of δ, branch points tracked from s=0), 30-digit Gauss–Legendre | all 3×6 period coordinates on all 7 cycles at s = 0.45+0.1i: 4e-15; κc∫_γ η_s vs mpmath 3F2 on the x<0 ray: 2e-16 (x≈−1455), 7e-16 (x≈−280), 6e-11 (x=−64, series truncation) (`period_all_cycles.txt`, `period_gamma_ray.txt`) |
| `analyse_series.py`, `eisenstein.py` | weight structure (exponents ≡ fixed class mod 14), denominators, growth in X = 1/x, Padé poles | only primes 2, 7 in denominators through s^100, valuations grow linearly; ratio/Padé estimates put the nearest singularity of the normal form near x ≈ −4 … −7 (rough) |

Usage examples:
```
python check_normalisation.py
python check_lattice.py
python reconstruct.py 72          # ~75 s; 100 takes ~6 min
python dump_series.py 100
python period_check_v.py series_N100.json "0.45+0.1j" 60
python period_check_v.py series_N100.json "0.703648334221227+0.561140821672860j" 100 gamma0
```
