"""Shared numerics: evaluate the reconstructed curve at complex s, branch points, root tracking."""
import json
import numpy as np
from fractions import Fraction

def load(path):
    d = json.load(open(path))
    f = lambda D: {int(k): float(Fraction(v)) for k, v in D.items()}
    return {"N": d["N"], "h": f(d["h"]), "p": {int(j): f(v) for j, v in d["p"].items()},
            "b": [f(x) for x in d["b"]], "P": [[f(x) for x in row] for row in d["P"]]}

def ev(D, s):
    return sum(c * s**k for k, c in D.items())

def coeffs(S, s):
    return ev(S["h"], s), {j: ev(S["p"][j], s) for j in range(1, 6)}

def vpoly(u, h, p):
    """Coefficients (high->low) of Phi(u,v) = v^2 - F(1,u,u^2+h v) as a cubic in v."""
    # F = u z^3 - 1 + p1 u + p2 z + p3 u z + p4 z^2 + p5 u z^2, z = u^2 + h v = A + B v
    A, B = u*u, h
    # z^k as polys in v (low->high)
    z1 = np.array([A, B], dtype=complex)
    z2 = np.convolve(z1, z1); z3 = np.convolve(z2, z1)
    F = np.zeros(4, dtype=complex)
    F[:4] += u * z3
    F[0] += -1 + p[1]*u
    F[:2] += p[2]*z1 + p[3]*u*z1
    F[:3] += p[4]*z2 + p[5]*u*z2
    Phi = -F
    Phi[2] += 1.0
    return Phi[::-1]   # high -> low

def Phi_v(u, v, h, p):
    z = u*u + h*v
    Fz = 3*u*z*z + p[2] + p[3]*u + 2*p[4]*z + 2*p[5]*u*z
    return 2*v - h*Fz

def branch_points(h, p):
    """Roots in u of the v-discriminant of Phi (cubic a v^3 + b v^2 + c v + d with coefficients polys in u)."""
    from numpy.polynomial import polynomial as Pl
    # build coefficients as polys in u (low->high) symbolically by sampling: Phi coefficients are polys of degree <= 8 in u
    us = np.exp(2j*np.pi*np.arange(16)/16)
    vals = np.array([vpoly(u, h, p) for u in us])  # rows: [a,b,c,d] at each u
    polys = [np.fft.fft(vals[:, k]) / 16 for k in range(4)]
    # fft with exp(+i) sampling: value(u_k) = sum c_n u_k^n -> c_n = (1/16) sum value * u_k^{-n}
    polys = [np.array([np.sum(vals[:, k] * us**(-n)) / 16 for n in range(16)]) for k in range(4)]
    polys = [np.trim_zeros(np.where(abs(c) < 1e-13, 0, c), 'b') for c in polys]
    a, b, c, d = polys
    m = Pl.polymul
    D = (18*m(m(a, b), m(c, d)) if len(a) else 0)
    D = Pl.polyadd(18*m(m(a, b), m(c, d)), -4*m(m(m(b, b), b), d))
    D = Pl.polyadd(D, m(m(b, b), m(c, c)))
    D = Pl.polyadd(D, -4*m(a, m(m(c, c), c)))
    D = Pl.polyadd(D, -27*m(m(a, a), m(d, d)))
    D = np.trim_zeros(np.where(abs(D) < 1e-14*np.max(abs(D)), 0, D), 'b')
    return np.roots(D[::-1])
