"""Solve to order N and dump h, p_j, b_i and the full period matrix P_ij(s) as exact rationals (JSON)."""
import sys, json
from reconstruct import solve
import sympy as sp
N = int(sys.argv[1])
h, p, a, b, extra, bcoef, res_ok, P = solve(N, verbose=False)
s = sp.symbols('s')
ser = lambda D: {str(k): f"{v.p}/{v.q}" for k, v in D.items()}
def symser(e):
    poly = sp.Poly(sp.expand(e), s)
    return {str(m[0]): str(c) for m, c in zip(poly.monoms(), poly.coeffs())}
out = {"N": N, "h": ser(h), "p": {str(j): ser(p[j]) for j in p},
       "b": [symser(e) for e in bcoef], "P": [[ser(P[i][j]) for j in range(6)] for i in range(3)],
       "residue_checks_ok": res_ok, "unimposed_residuals_zero": all(not v for v in extra.values())}
json.dump(out, open(f"series_N{N}.json", "w"), indent=1)
print("dumped", N, res_ok, out["unimposed_residuals_zero"])
