"""Section 5 lattice checks: invariance of H, the row J(v*,A^j v*), Gram determinant, im(B^2-I)."""
import sympy as sp
r = sp.sqrt(-7)
w = (-1 + r)/2
k = (7 + r)/2
cj = lambda z: sp.conjugate(z)
A = sp.Matrix([[0, 0, 1], [1, 0, -cj(w)], [0, 1, w]])
B = sp.Matrix([[0, 0, -1], [1, 0, 1], [0, 1, 1]])
H = sp.Matrix([[0, k, r], [cj(k), 0, k], [-r, cj(k), 0]])
simp = lambda M: M.applyfunc(lambda e: sp.nsimplify(sp.expand(e)))
print("H Hermitian:", simp(H - H.H) == sp.zeros(3))
print("A^* H A == H:", simp(A.H*H*A - H) == sp.zeros(3))
print("B^* H B == H:", simp(B.H*H*B - H) == sp.zeros(3))
t = sp.symbols('t')
print("charpoly A:", sp.factor(sp.expand((A.charpoly(t).as_expr()))), " ; charpoly B:", sp.factor(B.charpoly(t).as_expr()))
print("rank(A-B) =", (A-B).rank())
print("im(B^2-I) columns:", [list(c) for c in [(B**2 - sp.eye(3))[:, i] for i in range(3)]])
# signature of H
ev = [sp.N(e) for e in H.eigenvals()]
print("eigenvalues of H:", [sp.N(sp.re(e), 6) for e in ev])
vstar = sp.Matrix([-1, 0, 1])/r
J = lambda v, z: sp.nsimplify(sp.expand(2*sp.re(sp.expand((v.H*H*z)[0]/r))))
row = [J(vstar, (A**j)*vstar) for j in range(7)]
print("J(v*, A^j v*), j=0..6:", row)
G = sp.Matrix(6, 6, lambda a, b: J((A**a)*vstar, (A**b)*vstar))
print("Gram on A^j v*, j=0..5:\n", G, "\n det =", G.det())
print("A + A^2 + A^4 == w*I:", simp(A + A**2 + A**4 - w*sp.eye(3)) == sp.zeros(3))
